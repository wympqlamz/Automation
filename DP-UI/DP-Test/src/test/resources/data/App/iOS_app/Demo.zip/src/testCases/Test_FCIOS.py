#coding=utf-8
__author__ = 'Justin'

import unittest
import os
from src.base.Interncat import Interncat
PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class Demo():
    interncat = None
    def setUp(self):
        self.interncat = Interncat()
        self.interncat.openApp()

    def tearDown(self):
        self.interncat.quit()

    def test_scroll(self):

        # bool flag = self.interncat.verifyIsShown("allow")
        if (self.interncat.verifyIsShown("allow")):
            self.interncat.clickOn("allow")
        self.interncat.clickOn("search")
        self.interncat._waitByTimeOut(1000)
        self.interncat.clickOn("confirm")
        self.interncat._waitByTimeOut(1000)
        self.interncat.clickOn("selectCity")

        self.interncat._waitByTimeOut(1000)
        self.interncat.swipeOfType("up")
        self.interncat._waitByTimeOut(2000)
        self.interncat.swipeOfType("down")
        self.interncat._waitByTimeOut(1000)
        # self.interncat.getScreenShot("iOSImage.png")

        self.interncat.clickOn("city")

        self.interncat._waitByTimeOut(1000)
        self.interncat.clickOn("search")

        self.interncat._waitByTimeOut(1000)
        self.interncat.clickOn("changeCity")
        self.interncat._waitByTimeOut(1000)
        self.interncat.clickOn("firstCity")

        # self.interncat._waitByTimeOut(1000)
        # self.interncat.clickOn("back")

        self.interncat._waitByTimeOut(1000)
        self.interncat._driver.find_element_by_id("Back").click()
        # self.interncat.clickOn("Back")

        self.interncat._waitByTimeOut(1000)
        self.interncat.clickOn("login")

        self.interncat._waitByTimeOut(1000)
        self.interncat.clickOn("haslanded")

        self.interncat._waitByTimeOut(1000)
        # # sleep(3)
        #
        # els = self.interncat._findElements('Account')
        # els.send_keys('1345678925')
        self.interncat.setValueTo("Account","13446734223")
        self.interncat._waitByTimeOut(1000)

        #
        # elss = self.interncat._findElements('XCUIElementTypeTextField')[1]
        # print elss

    def test_demo(self):
        self.setUp()
        self.test_scroll()
        self.tearDown()
