#from src.testCases.Test_FCDemo1 import Demo
#from src.testCases.Test_ChromeBrowser import Browser
#rom src.testCases.Test_FCDemo1 import Demoifrom
#from src.testCases.Test_FCGodaddy import Godaddy

#from src.testCases.Test_FCFinance import financeDemo
#from src.testCases.Test_FCYahooWeather import yahooWeatherDemo
# from src.testCases.Test_FCToyota import todotaDemo
from src.testCases.Test_FCIOS import Demo
# from src.testCases.
# from src.testCases.Interncat import interncatDemo
#from src.testCases.Test_FCToyotaPs import todotaPsDemo
import unittest
import os
class Run():
    '''if __name__ == '__main__':
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(Demo,'test'))
        # suite =  unittest.TestLoader().loadTestsFromTestCase(MyTest)
        unittest.TextTestRunner(verbosity=2).run(suite)'''
    '''if __name__ == '__main__':
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(Demo, 'test'))
        # suite =  unittest.TestLoader().loadTestsFromTestCase(MyTest)
        unittest.TextTestRunner(verbosity=2).run(suite)'''

if __name__ == '__main__':
    # suite = unittest.TestSuite()
    # suite.addTest(unittest.makeSuite(todotaDemo, 'test'))

    # unittest.TextTestRunner(verbosity=2).run(suite)
    # #suite =  unittest.TestLoader().loadTestsFromTestCase(MyTest)
    # print os.getenv('app_device_platformName')

    demo=Demo()
    demo.test_demo()
    # suite = unittest.TestSuite()
    # suite.addTest(unittest.makeSuite(Demo, 'test'))
    # suite = unittest.TestSuite()
    # suite.addTest(unittest.makeSuite(interncatDemo,'test'))
    # unittest.TextTestRunner(verbosity=2).run(suite)
