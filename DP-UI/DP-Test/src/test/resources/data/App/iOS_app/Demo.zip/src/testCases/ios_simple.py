"""
Simple iOS tests, showing accessing elements and getting/setting text from them.
"""
import unittest
import os
import socket
from random import randint
from appium import webdriver
from time import sleep

class SimpleIOSTests(unittest.TestCase):

    def setUp(self):
        # set up appium
        #app = os.path.abspath('../../apps/TestApp/build/release-iphonesimulator/TestApp.app')
        self.driver = webdriver.Remote(
            command_executor='http://127.0.0.1:4723/wd/hub',
            desired_capabilities={
                'app': '/Users/yuyue/Desktop/Simulator.app',
                'platformName': 'iOS',
                'platformVersion': '9.3',
                'deviceName': 'iPhone 6',
                'udid': 'b66d1d31e2001d6c23e3a3d100afde8382ee2b49',
                'bundleId': 'com.lzz.toad.test'
            })
        x = (str)(self.driver.get_window_size()['width'])
        y = (str)(self.driver.get_window_size()['height'])
        print "x: " + x + " --  y: " + y

    def tearDown(self):
        self.driver.quit()

    def test_scroll(self):
        print "test minitouch"
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        host = "127.0.0.1"
        port = 2222
        print "hostname =",host
        s.bind((host, port))
        s.listen(1)
        while 1:
            conn, addr = s.accept()
            print "Connected by",addr
            w = self.driver.get_window_size()['width']
            h = self.driver.get_window_size()['height']
            print "W: " + str(w) + " --  H: " + str(h)

            while 1:
                data=conn.recv(1024)
                data = data.lstrip()
                print "recv data =",data

                if data[0] == 'd':
                	print "tap"
                	x = (data.split()[1]);
                	y = (data.split()[2]);

                	print "x =",x
                	print "y =",y
                	self.driver.tap([(x * w), (y * h),(x * w),(y * h)], 0)
                	#self.driver.switch_to_alert().accept()
                elif data[0] == 'm':
                	print "swipe"
                	x1 = int(data.split()[1]);
                	y1 = int(data.split()[2]);
                	x2 = int(data.split()[3]);
                	y2 = int(data.split()[4]);
                	print "x1 =",x1
                	print "y1 =",y1
                	print "x2 =",x2
                	print "y2 =",y2
                	self.driver.swipe(x1, y1, x2, y2, duration=500)
                else:
                	pass

if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(SimpleIOSTests)
    unittest.TextTestRunner(verbosity=2).run(suite)
