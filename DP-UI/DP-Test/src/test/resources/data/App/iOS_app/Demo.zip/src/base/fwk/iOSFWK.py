#coding=utf-8
__author__ = 'Justin'

import os

from src.base.core.UiFramework import UIFramework
from selenium.common.exceptions import NoSuchElementException
from appium import webdriver
from selenium.webdriver.common.by import By
from src.utils.ApiRequest import wdaRun


PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)


class iOS(UIFramework):
    def __init__(self):
        UIFramework.__init__(self)


    def getAppType(self):
        return "IOS"


    def __launch_app_DP(self):

        desired_caps = {}

        desired_caps['platformName'] = os.getenv('APP_DEVICE_PLATFORMNAME')  # 平台 APP_DEVICE_PLATFORMNAME=iOS
        desired_caps['platformVersion'] = os.getenv('APP_DEVICE_VERSION')  # 系统版本 APP_DEVICE_VERSION='9.3'
        desired_caps['deviceName'] = os.getenv('APP_DEVICE_NAME')  # 设备型号 APP_DEVICE_NAME='iPhone 4s'
        desired_caps['newCommandTimeout'] = os.getenv('APP_COMMAND_TIMEOUT')
        desired_caps['app'] = os.getenv('APP_PATH')  # app路径 APP_PATH='/xxxx/xxxx/xxxx.app'
        desired_caps['udid'] = os.getenv('APP_UDID')  # 设备序列号 APP_UDID='ac7e1f11ae528e710360cfcefc21ed15bc027b80'
        desired_caps['bundleId'] = os.getenv('APP_BUNDLEIDENTIFIER')  # 系统版本
        desired_caps['automationName'] = "XCUITest"

        desired_caps['webDriverAgentUrl'] = "http://localhost:8100"
        desired_caps['noReset'] = True
        self._driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)

    def __launch_app(self,bundleId=None):

        desired_caps = {}
        desired_caps['platformName'] = self._getSutFullFileName("app.device.platformName")
        desired_caps['deviceName'] = self._getSutFullFileName("app.device.name")
        desired_caps['version'] = self._getSutFullFileName("app.device.version")
        desired_caps['newCommandTimeout'] = self._getSutFullFileName("app.command.timeout")
        desired_caps['app'] = PATH(self._getSutFullFileName("app.path"))
        desired_caps['udid'] = self._getSutFullFileName("app.udid")
        if bundleId == None:
            desired_caps['bundleId'] = self._getSutFullFileName("app.bundleId")
        else:
            desired_caps['bundleId'] = bundleId
        desired_caps['webDriverAgentUrl'] = "http://localhost:8100"
        desired_caps['automationName'] = "XCUITest"
        desired_caps['noReset'] = True
        desired_caps['wdaConnectionTimeout'] = 120000
        self._driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)



    def openApp(self,bundleId=None, page = ""):
        self.UiMapSetPage(page)
        if os.getenv('APP_DEVICE_PLATFORMNAME') == None:
            self.__launch_app(bundleId)
        else:
            self.__launch_app_DP()
        self.wda = wdaRun()


    def getX(self):
        width = self._driver.get_window_size()['width']
        return width

    def getY(self):
        height = self._driver.get_window_size()['height']
        return height

    def swipeOfType(self,type):
        self.waitForTimeOut(500)
        self.log("Swiping " + type + ".")
        windows_x = self.getX()
        windows_y = self.getY()

        swipeLeft = "left"
        swipeLeftSide = "leftSide"
        swipeRight = "right"
        swipeRightSide = "rightSide"
        swipeUp = "up"
        swipeTop = "top"
        swipeDown = "down"
        swipeBottom = "bottom"

        # Sliding screen to the left
        if type.lower() == swipeLeft.lower():
            # self._driver.swipe((windows_x * 0.9), (windows_y * 0.5),(windows_x * 0.2), (windows_y * 0.5),1500)
            self._driver.swipe((windows_x * 0.5), (windows_y * 0.5), (windows_x * -0.4), 0, 500)
        # From the left of screen to began to slip
        if type.lower() == swipeLeftSide.lower():
            # self._driver.swipe(1, (windows_y * 0.5),(windows_x * 0.9), (windows_y * 0.5),1500)
            self._driver.swipe((windows_x * 1.0), (windows_y * 0.5), (windows_x * -0.8), 0, 500)
        # Sliding screen to the right
        if type.lower() == swipeRight.lower():
            # self._driver.swipe((windows_x * 0.2), (windows_y * 0.5),(windows_x * 0.9), (windows_y * 0.5),1500)
            self._driver.swipe((windows_x * 0.4), (windows_y * 0.5), (windows_x * 0.4), 0, 500)
        # From the right of screen to began to slip
        if type.lower() == swipeRightSide.lower():
            # self._driver.swipe((windows_x * 0.9), (windows_y * 0.5),(windows_x * 0.2), (windows_y * 0.5),1500)
            self._driver.swipe((0), (windows_y * 0.5), (windows_x * 0.9), 0, 500)
        # Screen upward sliding
        if type.lower() == swipeUp.lower():
            # self._driver.swipe((windows_x * 0.5), (windows_y * 0.9),(windows_x * 0.5), (-windows_y * 0.4),1500)
            self._driver.swipe((windows_x * 0.5), (windows_y * 0.5), 0, (windows_y * -0.4), 500)
        # From the top of screen to began to slip
        if type.lower() == swipeTop.lower():
            # self._driver.swipe((windows_x * 0.5),0 ,(windows_x * 0.5), (windows_y * 0.8),1500)
            self._driver.swipe((windows_x * 0.5), 0, 0, (windows_y * 0.9), 500)
        # Slide down the screen
        if type.lower() == swipeDown.lower():
            # self._driver.swipe((windows_x * 0.5), (windows_y * 0.4),(windows_x * 0.5), (windows_y * 0.9),1500)
            self._driver.swipe((windows_x * 0.5), (windows_y * 0.4), 0, (windows_y * 0.5), 500)
        # From the bottom of screen to began to slip
        if type.lower() == swipeBottom.lower():
            # self._driver.swipe((windows_x * 0.5), (windows_y * 0.9),(windows_x * 0.5), (windows_y * 0.1),1500)
            self._driver.swipe((windows_x * 0.5), (windows_y * 1.0), 0, (windows_y * -0.9), 1500)



    def tapForPoint(self,x,y):
        self.wda.tap(x,y)

    def keys(self,value):
        self.wda.keys(value)

    def home(self):
        self.wda.home()

    def launchApp(self,bundleId):
        self.openApp(bundleId)


    def flick(self,start_x,start_y,end_x,end_y):
        self._driver.flick(start_x,start_y,end_x,end_y)

    def quit(self):
        self._driver.quit()

    def getPageSources(self):
        return self._driver.page_source

    def switchToWebView(self,viewName):
        self._driver.switch_to.context(viewName)

    def logContext(self):
        contextName = self._driver.contexts
        for context in iter(contextName):
            self.log("Context : " + context)

    def getScreenShot(self,name):
        self._driver.get_screenshot_as_file(os.getenv("APPIUM_SCREENSHOT_DIR")+name)

        self._driver.get_screenshot_as_file("/Users/devicepass/Desktop/"+name)