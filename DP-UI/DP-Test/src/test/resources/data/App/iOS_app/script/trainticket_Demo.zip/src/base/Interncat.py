# -*- coding: utf-8 -*-
__author__ = 'Justin'

import os
import time
from .fwk.iOSFWK import iOS

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class Interncat(iOS):

    def __init__(self):
        iOS.__init__(self)

    def getAppName(self):
        return "interncat"
