#coding=utf-8
__author__ = 'Justin'

import unittest
import os
from src.base.FinanceApp import finance

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class financeDemo(unittest.TestCase):
    finance = None

    @classmethod
    def setUpClass(self):

        self.finance= finance()
        self.finance.openApp()


    def verifyHome(self):

        self.finance.verifyIsShown("notNow")
        self.finance.clickOn("notNow")
        self.finance.verifyIsShown("transaction")
        self.finance.verifyIsShown("symbol", 1)
        self.finance.verifyIsShown("price", 1)
        self.finance.verifyIsShown("percentage" , 1)
        self.finance.verifyIsShown("listEmpty")
        self.finance.verifyIsShown("addSymbolsMsg")
        self.finance.verifyIsShown("blueButton")
        self.finance.verifyIsShown("home")
        self.finance.verifyIsShown("news")
        #self.finance.verifyIsShown("explore")
        self.finance.verifyIsShown("markets")

        symbol = self.finance.getElements("symbol")
        price = self.finance.getElements("price")
        percentage = self.finance.getElements("percentage")

        for index in range(len(symbol)):
            self.finance.log(symbol[index].text)
            self.finance.log(price[index].text)
            self.finance.log(percentage[index].text)
            self.finance.log("**************")

        listEmpty = self.finance.getValueOf("listEmpty")
        addSymbolsMsg = self.finance.getValueOf("addSymbolsMsg")
        self.finance.log(listEmpty)
        self.finance.log(addSymbolsMsg)
        # add symbol

        self.finance.clickOn("blueButton")
        self.finance.verifyIsShown("searchEdit")
        self.finance.setValueTo("searchEdit","yahoo")

        self.finance.verifyIsShown("allSearchResult", 1)
        allSearchResult = self.finance.getElements("allSearchResult")
        self.finance.waitForTimeOut(5000)
        for element in iter(allSearchResult):
            self.finance.log(element.text)

        self.finance.clickOn("allSearchResult", 1)
        self.finance.getScreenShot("Home.png")

    def myWatchlist(self):

        self.finance.setPage("home")
        self.finance.clickOn("fullscreen")
        self.finance.verifyIsShown("title")
        self.finance.verifyIsShown("message")
        self.finance.verifyIsShown("maybeLater")
        self.finance.log(self.finance.getValueOf("title"))
        self.finance.log(self.finance.getValueOf("message"))
        self.finance.clickOn("maybeLater")
        self.finance.verifyIsShown("news")

    def news(self):

        self.finance.clickOn("news")
        self.finance.verifyIsShown("newsTitle")
        self.finance.verifyIsShown("newsSubtitle")
        newsTitle = self.finance.getValueOf("newsTitle")
        newsSubtitle = self.finance.getValueOf("newsSubtitle")
        self.finance.log("Title : " + newsTitle)
        self.finance.log("newsSubtitle : " + newsSubtitle)

    def explore(self):

        self.finance.setPage("home")
        self.finance.verifyIsShown("explore")
        self.finance.clickOn("explore")
        self.finance.waitForTimeOut(2000)
        self.finance.getScreenShot("explore.png")


    def markets(self):
        self.finance.setPage("home")
        self.finance.clickOn("markets")

        self.finance.verifyIsShown("markers")
        self.finance.verifyIsShown("5D")
        self.finance.verifyIsShown("3M")
        self.finance.getScreenShot("1D.png")

        self.finance.clickOn("5D")
        self.finance.waitForTimeOut(3000)
        self.finance.getScreenShot("5D.png")

        self.finance.clickOn("3M")
        self.finance.waitForTimeOut(3000)
        self.finance.getScreenShot("3M.png")

    def closeApp(self):
        self.finance.quit()

    def test_financeDemo(self):

        self.verifyHome()
        self.myWatchlist()
        self.news()
        self.explore()
        self.markets()
        self.closeApp()
