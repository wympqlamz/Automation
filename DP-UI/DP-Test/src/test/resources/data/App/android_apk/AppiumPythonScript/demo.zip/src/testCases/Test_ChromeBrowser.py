#coding=utf-8
__author__ = 'Justin'

import unittest
from time import sleep
from appium import webdriver
import os

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class Browser(unittest.TestCase):

    _driver = None

    @classmethod
    def setUpClass(self):

        desired_caps = {}
        desired_caps['platformName'] = os.getenv("APPIUM_PLATFORM")
        desired_caps['platformVersion'] = os.getenv("APPIUM_DEVICE_VERSION")
        desired_caps['automationName'] = os.getenv("APPIUM_AUTOMATION_NAME")
        desired_caps['deviceName'] = os.getenv("APPIUM_DEVICE_NAME");
        desired_caps['newCommandTimeout'] = os.getenv("APPIUM_NEW_COMMAND_TIMEOUT")
        desired_caps['browserName'] = "chrome"
        self._driver = webdriver.Remote(os.getenv("APPIUM_URL"), desired_caps)

        '''desired_caps = {}
        desired_caps['platformName'] = "Android"
        desired_caps['platformVersion'] = "4.4"
        desired_caps['deviceName'] = "HTC D816w"
       # desired_caps['app'] = "C:\\Users\\kevin\\Desktop\\Browser\\Chrome.apk"
        desired_caps['newCommandTimeout'] = "2000"
        desired_caps['browserName'] = "chrome"
        self._driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub", desired_caps)'''

    def test_browser_test1(self):

        self._driver.get("https://www.yahoo.com/")
        self.switchToWebView()
      #  self.waitForTimeOut(2)
        search = self._driver.find_element_by_id("placeHolder-search-btn")
        search.click()
        self.waitForTimeOut(1)
        search2 = self._driver.find_element_by_id("search-box")
        search2.send_keys("test")
        self.waitForTimeOut(1)
        self.native_app()
        self._driver.press_keycode(66)
        self.switchToWebView()
       # more = self._driver.find_element_by_id("ext-pivot")
        while(True):
            self.waitForTimeOut(1)
            more = self._driver.find_element_by_id("ext-pivot")
            if more.is_displayed():
                break
        self.native_app()
        x = self._driver.get_window_size("width")
        y = self._driver.get_window_size("height")

      # self._driver.swipe(x * 0.5 , y * 0.5 , x * 0.5 , (y * 0.5) - 200,1500)
       # self.waitForTimeOut(1)
       # self._driver.swipe(x * 0.5, y * 0.5 +200 , x * 0.5, (y * 0.5) , 1500)


        self.waitForTimeOut(1)
        self.switchToWebView()
        first = self._driver.find_element_by_xpath("(//*[@class='compTitle'])[1]")
        text = first.text
        firstLink = self._driver.find_element_by_xpath("(//*[@class='compTitle'])[1]//a")
        firstLink.click()
        self.waitForTimeOut(3)
        print text


    def switchToWebView(self):
        contextName = self._driver.contexts
        for context in iter(contextName):
            if context == "WEBVIEW_1":
                self._driver.switch_to.context(context)


    def native_app(self):
        self._driver.switch_to.context("NATIVE_APP");

    def waitForTimeOut(self,time):
        try:
            sleep(time)
        except TimeoutError as e:
            print(e)

