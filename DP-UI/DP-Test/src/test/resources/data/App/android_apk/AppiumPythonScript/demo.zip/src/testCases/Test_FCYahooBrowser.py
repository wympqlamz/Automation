#coding=utf-8
__author__ = 'Justin'

import unittest
import os
from src.base.YahooMobileBrowser import yaHooBrowser

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class yoHooMobileBrowser(unittest.TestCase):
    yaHoo = None

    @classmethod
    def setUpClass(self):
        self.yaHoo = yaHooBrowser()
        self.yaHoo.openMobileBrowser()
        #go to welcome page

    def test_YahooBorwser(self):

        self.yaHoo.logContext()
        self.yaHoo.switchToWebView("WEBVIEW_1")

        self.openFirstArticle()


    def openFirstArticle(self):

        self.yaHoo.verifyIsShown("logo")
        self.yaHoo.verifyIsShown("menuBtn")
        self.yaHoo.verifyIsShown("search")
        self.yaHoo.clickOn("search")
        self.yaHoo.verifyIsShown("searchBox")
        self.yaHoo.setValueTo("searchBox", "yahoo")
        self.yaHoo.switchToWebView("NATIVE_APP")
        self.yaHoo.waitForTimeOut(1000)
        self.yaHoo.pressKey(66)
        self.yaHoo.switchToWebView("WEBVIEW_1")
        self.yaHoo.verifyIsShown("news")
        self.yaHoo.clickOn("news")
        self.yaHoo.waitForTimeOut(2000)
        self.yaHoo.verifyIsShown("searchResult", 1)
        self.yaHoo.switchToWebView("NATIVE_APP")
        self.yaHoo.swipeOfType("up")
        self.yaHoo.waitForTimeOut(1000)
        self.yaHoo.swipeOfType("down")
        self.yaHoo.waitForTimeOut(1000)
        self.yaHoo.switchToWebView("WEBVIEW_1")
        searchResult = self.yaHoo.getElements("searchResult")
        for element in iter(searchResult):
            self.yaHoo.log(element.text)
        title2 = self.yaHoo.getValueOf("searchResultTitle", 2)
        self.yaHoo.clickOn("searchResultTitle", 2)
        self.yaHoo.verifyIsShown("articleHeadline")
        self.yaHoo.verifyIsShown("article")

        article = self.yaHoo.getValueOf("article")
        articleHeadline = self.yaHoo.getValueOf("articleHeadline")
        self.yaHoo.log(article)
        self.yaHoo.log(title2)
        self.yaHoo.log(articleHeadline)

        self.yaHoo.switchToWebView("NATIVE_APP")
        self.yaHoo.swipeOfType("up")
        self.yaHoo.waitForTimeOut(1000)
        self.yaHoo.swipeOfType("down")
        self.yaHoo.waitForTimeOut(1000)
        self.yaHoo.getScreenShot("article.png")