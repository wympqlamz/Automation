#coding=utf-8
__author__ = 'Justin'

import unittest
import os
from src.base.ToyotaApp import toyota

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class todotaDemo(unittest.TestCase):
    toyota = None
    userName = None
    password = None

    @classmethod
    def setUpClass(self):

        self.toyota= toyota()
        self.toyota.openApp()
        self.userName = self.toyota._getSutFullFileName("app.toyota.userName")
        self.password = self.toyota._getSutFullFileName("app.toyota.password")
        #go to welcome page

    def toyotaLogin(self):

        self.toyota.verifyIsShown("homeButton")
        self.toyota.verifyIsShown("numberconter")
        self.toyota.verifyIsShown("agent")
        self.toyota.verifyIsShown("carPlay")
        self.toyota.verifyIsShown("magazine")

        self.toyota.clickOn("homeButton")
        self.toyota.verifyIsShown("usericon")
        self.toyota.verifyIsShown("phoneNumber")
        self.toyota.verifyIsShown("serviceTle")
        phoneNumber = self.toyota.getValueOf("phoneNumber")
        serviceTle = self.toyota.getValueOf("serviceTle")
        self.toyota.log("Server Tel && Phone : " + serviceTle + phoneNumber)

        self.toyota.clickOn("usericon")
        self.toyota.verifyIsShown("userName")
        self.toyota.verifyIsShown("password")
        self.toyota.verifyIsShown("signinButton")
        self.toyota.verifyIsShown("homeButton")

        self.toyota.setValueTo("userName", self.userName)
        self.toyota.waitForTimeOut(800)
        self.toyota.setValueTo("password", self.password)
        self.toyota.waitForTimeOut(800)
        self.toyota.clickOn("signinButton")
        self.toyota.waitForTimeOut(1500)
        self.toyota.getScreenShot("Login.png")

        self.toyota.waitForTimeOut(2000)
        self.toyota.clickOn("homeButton")
        self.toyota.verifyIsShown("usericon")
        self.toyota.verifyIsShown("phoneNumber")
        self.toyota.verifyIsShown("serviceTle")

    def toyotaAgent(self):

        self.toyota.verifyIsShown("homeButton")
        self.toyota.clickOn("homeButton")
        self.toyota.verifyIsShown("homeButton")
        self.toyota.verifyIsShown("numberconter")
        self.toyota.verifyIsShown("agent")
        self.toyota.verifyIsShown("carPlay")
        self.toyota.verifyIsShown("magazine")

        self.toyota.clickOn("agent")
        self.toyota.verifyIsShown("agentTitle")
        self.toyota.verifyIsShown("agentSearch")
        self.toyota.verifyIsShown("homeButton")

        title = self.toyota.getValueOf("agentTitle")
        self.toyota.log(title)
        self.toyota.verifyIsShown("agengNames",1)
        elements = self.toyota.getElements("agengNames")
        for element in iter(elements):
            self.toyota.log(element.text)

        self.toyota.clickOn("homeButton")
        self.toyota.verifyIsShown("homeButton")
        self.toyota.verifyIsShown("numberconter")
        self.toyota.verifyIsShown("agent")
        self.toyota.verifyIsShown("carPlay")
        self.toyota.verifyIsShown("magazine")

    def toyotaCarPlay(self):

        self.toyota.clickOn("carPlay")
        self.toyota.verifyIsShown("actionImg1")
        self.toyota.verifyIsShown("carPlayTitle")
        self.toyota.verifyIsShown("actionTitles", 1)
        self.toyota.verifyIsShown("actionTimes", 1)
        self.toyota.verifyIsShown("homeButton")

        self.toyota.log(self.toyota.getValueOf("carPlayTitle"))

        titles = self.toyota.getElements("actionTitles")
        for element1 in iter(titles):
            self.toyota.log(element1.text)

        times = self.toyota.getElements("actionTimes")
        for element2 in iter(times):
            self.toyota.log(element2.text)

        self.toyota.swipeOfType("up")
        self.toyota.waitForTimeOut(1000)
        self.toyota.swipeOfType("down")
        self.toyota.waitForTimeOut(1000)
        self.toyota.clickOn("homeButton")

    def toyotaMagazine(self):

        self.toyota.verifyIsShown("homeButton")
        self.toyota.verifyIsShown("numberconter")
        self.toyota.verifyIsShown("agent")
        self.toyota.verifyIsShown("carPlay")
        self.toyota.verifyIsShown("magazine")

        self.toyota.clickOn("magazine")
        self.toyota.verifyIsShown("magazineTitle")
        self.toyota.log(self.toyota.getValueOf("magazineTitle"))
        self.toyota.verifyIsShown("firstRead")
        self.toyota.swipeOfType("up")
        self.toyota.waitForTimeOut(1000)
        self.toyota.swipeOfType("down")
        self.toyota.waitForTimeOut(1000)
        '''self.toyota.clickOn("firstRead")
        self.toyota.verifyIsShown("magazineTitle")
        self.toyota.waitForTimeOut(2000)
        self.toyota.swipeOfType("up")
        self.toyota.waitForTimeOut(1000)
        self.toyota.clickOn("homeButton1")
        self.toyota.verifyIsShown("firstRead")
        self.toyota.clickOn("homeButton")
        self.toyota.verifyIsShown("numberconter")
        self.toyota.verifyIsShown("agent")
        self.toyota.verifyIsShown("carPlay")
        self.toyota.verifyIsShown("magazine")'''
        self.toyota.getScreenShot("magazine.png")

    def quitApp(self):
        self.toyota.quit()

    def test_Toyota(self):
        # login toyota
        self.toyotaLogin()

        # Check retailers
        self.toyotaAgent()

        # Promotions
        self.toyotaCarPlay()

        # Magazaine
        self.toyotaMagazine()

        # Close App
        self.quitApp()

