#coding=utf-8
__author__ = 'Justin'

import unittest
import os
from src.base.YaHooWeather import yahooWeather

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class yahooWeatherDemo(unittest.TestCase):
    weather = None
    userName = None
    password = None

    @classmethod
    def setUpClass(self):

        self.weather= yahooWeather()
        self.weather.openApp()


    def getCurrentWeather(self):

        self.weather.verifyIsShown("enableNotificatons")
        self.weather.verifyIsShown("noThanks")
        self.weather.verifyIsShown("subtitleText")
        self.weather.clickOn("noThanks")

        self.weather.verifyIsShown("continueBtn")
        self.weather.verifyIsShown("itemImage", 1)
        self.weather.verifyIsShown("itemTitle", 1)
        self.weather.swipeOfType("left")

        self.weather.clickOn("continueBtn")

        self.weather.verifyIsShown("sidebarButton")
        self.weather.verifyIsShown("location")
        self.weather.verifyIsShown("localTime")
        self.weather.verifyIsShown("addLocationButton")
        self.weather.verifyIsShown("weatherDescription")
        self.weather.verifyIsShown("high")
        self.weather.verifyIsShown("low")
        self.weather.verifyIsShown("ature")

        location = self.weather.getValueOf("location")
        localTime = self.weather.getValueOf("localTime")
        weatherDescription = self.weather.getValueOf("weatherDescription")
        high = self.weather.getValueOf("high")
        low = self.weather.getValueOf("low")
        ature = self.weather.getValueOf("ature")

        self.weather.log("location : " +  location)
        self.weather.log("local Time : " + localTime)
        self.weather.log("Weather Description : " + weatherDescription)
        self.weather.log("high : " + high)
        self.weather.log("low : " + low)
        self.weather.log("ature : " + ature)
        self.weather.getScreenShot("dufault.png")

    def addCity(self):

        self.weather.verifyIsShown("addLocationButton")
        self.weather.clickOn("addLocationButton")
        self.weather.verifyIsShown("searchBox")
        self.weather.setValueTo("searchBox", "430000")
        self.weather.waitForTimeOut(2000)

        self.weather.verifyIsShown("locationNames" , 1)

        elements = self.weather.getElements("locationNames")
        for element in iter(elements):
            self.weather.log(element.text)

        self.weather.clickOn("locationNames" , 1)
        self.weather.setPage("home")
        self.weather.verifyIsShown("location")
        self.weather.verifyIsShown("localTime")
        self.weather.verifyIsShown("addLocationButton")
        self.weather.verifyIsShown("weatherDescription")
        self.weather.verifyIsShown("high")
        self.weather.verifyIsShown("low")
        self.weather.verifyIsShown("ature")



    def getWeather(self):

        location = self.weather.getValueOf("location")
        localTime = self.weather.getValueOf("localTime")
        weatherDescription = self.weather.getValueOf("weatherDescription")
        high = self.weather.getValueOf("high")
        low = self.weather.getValueOf("low")
        ature = self.weather.getValueOf("ature")

        self.weather.log("location : " + location)
        self.weather.log("local Time : " + localTime)
        self.weather.log("Weather Description : " + weatherDescription)
        self.weather.log("high : " + high)
        self.weather.log("low : " + low)
        self.weather.log("ature : " + ature)
        self.weather.getScreenShot("wuhan.png")

    def getNewYorkWeather(self):

        self.weather.clickOn("sidebarButton")
        self.weather.verifyIsShown("newYork")
        self.weather.clickOn("newYork")
        self.weather.verifyIsShown("location")
        self.weather.verifyIsShown("localTime")
        self.weather.verifyIsShown("addLocationButton")
        self.weather.verifyIsShown("weatherDescription")
        self.weather.verifyIsShown("high")
        self.weather.verifyIsShown("low")
        self.weather.verifyIsShown("ature")

        location = self.weather.getValueOf("location")
        localTime = self.weather.getValueOf("localTime")
        weatherDescription = self.weather.getValueOf("weatherDescription")
        high = self.weather.getValueOf("high")
        low = self.weather.getValueOf("low")
        ature = self.weather.getValueOf("ature")
        self.weather.log("location : " + location + " -- local Time : " + localTime + " -- Weather Description : " + weatherDescription + " -- high : " + high +" -- low : " + low + " -- ature : " + ature)
        self.weather.getScreenShot("newYork.png")

    def test_yaHooWeatherDemo(self):

        self.getCurrentWeather()
        # add city
        self.addCity()
        self.getWeather()
        self.getNewYorkWeather()

