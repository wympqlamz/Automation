#coding=utf-8
__author__ = 'Justin'

from time import sleep
from appium import webdriver
import os

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class Demo():
    if __name__ == '__main__':
        desired_caps = {}
        #        desired_caps['appium-version'] = '1.0'
        desired_caps['platformName'] = 'iOS'
        desired_caps['platformVersion'] = '9.3'
        desired_caps['deviceName'] = 'iPhone 6'
        desired_caps['app'] = PATH('/Users/luojinming/Desktop/appium Demo/Payload/Simulator.app')
        desired_caps['udid'] = 'b66d1d31e2001d6c23e3a3d100afde8382ee2b49'
        desired_caps['bundleId'] = 'com.lzz.toad.test'
        driver = webdriver.Remote('http://10.10.59.30:4723/wd/hub', desired_caps)



