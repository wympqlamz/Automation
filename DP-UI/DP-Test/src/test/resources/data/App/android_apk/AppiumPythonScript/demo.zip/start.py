#from src.testCases.Test_FCDemo1 import Demo
#from src.testCases.Test_ChromeBrowser import Browser
#rom src.testCases.Test_FCDemo1 import Demoifrom
#from src.testCases.Test_FCGodaddy import Godaddy

#from src.testCases.Test_FCFinance import financeDemo
from src.testCases.Test_FCDemo1 import Demo

import unittest
class Run(unittest.TestCase):
    '''if __name__ == '__main__':
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(Demo,'test'))
        # suite =  unittest.TestLoader().loadTestsFromTestCase(MyTest)
        unittest.TextTestRunner(verbosity=2).run(suite)'''
    '''if __name__ == '__main__':
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(Demo, 'test'))
        # suite =  unittest.TestLoader().loadTestsFromTestCase(MyTest)
        unittest.TextTestRunner(verbosity=2).run(suite)'''

if __name__ == '__main__':
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Demo, 'test'))
    unittest.TextTestRunner(verbosity=2).run(suite)
    # suite =  unittest.TestLoader().loadTestsFromTestCase(MyTest)

