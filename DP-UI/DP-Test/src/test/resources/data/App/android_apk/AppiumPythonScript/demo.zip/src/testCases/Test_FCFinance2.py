#coding=utf-8
__author__ = 'Justin'

import unittest
import os
from src.base.FinanceApp import finance

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class financeDemo(unittest.TestCase):
    finance = None

    @classmethod
    def setUpClass(self):

        self.finance= finance()
        self.finance.openApp()


    def verifyHome(self):

        self.finance.verifyIsShown("notNow")
        self.finance.clickOn("notNow")
        self.finance.verifyIsShown("transaction")
        self.finance.verifyIsShown("symbol", 1)
        self.finance.verifyIsShown("price", 1)
        self.finance.verifyIsShown("percentage" , 1)
        self.finance.swipeOfType("down")
        self.finance.verifyIsShown("home")
        self.finance.verifyIsShown("news")
        self.finance.verifyIsShown("explore")
        self.finance.verifyIsShown("markets")
        self.finance._waitForElement("basic",20000)
        self.finance._waitForElement("details", 20000)
        symbol = self.finance.getElements("symbol")
        price = self.finance.getElements("price")
        percentage = self.finance.getElements("percentage")

        for index in range(len(symbol)):
            self.finance.log(symbol[index].text)
            self.finance.log(price[index].text)
            self.finance.log(percentage[index].text)
            self.finance.log("**************")

        self.finance.getScreenShot("Home.png")

        self.finance.clickOn("symbol", 1)
        self.finance.setPage("dow")
        self.finance.verifyIsShown("price")
        self.finance.verifyIsShown("5D")
        self.finance.verifyIsShown("5Y")
        price = self.finance.getValueOf("price")
        self.finance.log(price)

        self.finance.getScreenShot("1D.png")
        self.finance.clickOn("5D")
        self.finance.waitForTimeOut(4000)
        self.finance.getScreenShot("5D.png")

        self.finance.verifyIsShown("5Y")
        self.finance.clickOn("5Y")
        self.finance.waitForTimeOut(4000)
        self.finance.getScreenShot("5Y.png")
        self.finance.verifyIsShown("back")
        self.finance.clickOn("back")
        self.finance._waitForElement("basic", 5000)
        self.finance._waitForElement("details", 5000)


    def myWatchlist(self):

        self.finance.setPage("home")
        self.finance.clickOn("fullscreen")
        self.finance.verifyIsShown("title")
        self.finance.verifyIsShown("message")
        self.finance.verifyIsShown("maybeLater")
        self.finance.log(self.finance.getValueOf("title"))
        self.finance.log(self.finance.getValueOf("message"))
        self.finance.clickOn("maybeLater")
        self.finance.verifyIsShown("news")

    def news(self):

        self.finance.clickOn("news")
        self.finance.waitForTimeOut(2000)
        self.finance.swipeOfType("down")
        self.finance.verifyIsShown("newsTitle")
        #self.finance.verifyIsShown("newsSubtitle")
        newsTitle = self.finance.getValueOf("newsTitle")
        #newsSubtitle = self.finance.getValueOf("newsSubtitle")
        self.finance.log("Title : " + newsTitle)
        #self.finance.log("newsSubtitle : " + newsSubtitle)
        self.finance.swipeOfType("up")
        self.finance.waitForTimeOut(1000)
        self.finance.swipeOfType("down")
        self.finance.waitForTimeOut(1000)
        self.finance.getScreenShot("News.png")


    def explore(self):

        self.finance.setPage("home")
        self.finance.verifyIsShown("explore")
        self.finance.clickOn("explore")
        self.finance.waitForTimeOut(2000)
        self.finance.getScreenShot("explore.png")


    def markets(self):
        self.finance.setPage("home")
        self.finance.clickOn("markets")

        self.finance.verifyIsShown("markers")
        self.finance.verifyIsShown("5D")
        self.finance.verifyIsShown("3M")
        self.finance.getScreenShot("1D.png")

        self.finance.clickOn("5D")
        self.finance.waitForTimeOut(3000)
        self.finance.getScreenShot("M_5D.png")

        self.finance.clickOn("3M")
        self.finance.waitForTimeOut(3000)
        self.finance.getScreenShot("M_3M.png")

    def closeApp(self):
        self.finance.quit()

    def test_financeDemo(self):

        self.verifyHome()
        #self.myWatchlist()
        self.news()
        self.explore()
        self.markets()
        self.closeApp()
