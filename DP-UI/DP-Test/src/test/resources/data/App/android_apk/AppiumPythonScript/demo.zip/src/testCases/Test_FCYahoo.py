#coding=utf-8
__author__ = 'Justin'

import unittest
import os
from src.base.YaHooApp import yahoo

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class yahooDemo(unittest.TestCase):
    yahoo = None
    userName = None
    password = None

    @classmethod
    def setUpClass(self):

        self.yahoo= yahoo()
        self.yahoo.openApp()
        self.userName = self.yahoo._getSutFullFileName("app.yahoo.userName")
        self.password = self.yahoo._getSutFullFileName("app.yahoo.password")

    def signInYohoo(self):

        self.yahoo.verifyIsShown("logo")
        self.yahoo.verifyIsShown("login")
        self.yahoo.verifyIsShown("register")
        self.yahoo.clickOn("login")

        self.yahoo.waitForTimeOut(2000)

        self.yahoo.setValueByKeys(self.userName)
        self.yahoo.waitForTimeOut(1000)
        # set enter
        self.yahoo.pressKey(61)
        self.yahoo.waitForTimeOut(1000)
        self.yahoo.pressKey(66)
        self.yahoo.waitForTimeOut(1000)


    def test_yaHooDemo(self):

        self.signInYohoo()

