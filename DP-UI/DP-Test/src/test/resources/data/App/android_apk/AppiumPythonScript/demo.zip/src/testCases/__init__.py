from src.testCases.Test_FCDemo1 import Demo
from src.testCases.Test_FCToyota import toyota