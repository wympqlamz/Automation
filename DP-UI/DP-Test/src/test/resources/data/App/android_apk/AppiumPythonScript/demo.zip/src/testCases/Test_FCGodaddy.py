#coding=utf-8
__author__ = 'Justin'

import unittest
import os
from src.base.ChromeApp import chrome

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class Godaddy(unittest.TestCase):
    godaddy = None

    @classmethod
    def setUpClass(self):
        self.godaddy = chrome()
        self.godaddy.openMobileBrowser()
        #go to welcome page

    def test_godaddy_search(self):

        self.godaddy.logContext()
        self.godaddy.switchToWebView("WEBVIEW_1")

        self.godaddy.verifyIsShown("logo")
        self.godaddy.verifyIsShown("menu")
        self.godaddy.verifyIsShown("cart")
        self.godaddy.verifyIsShown("title")
        self.godaddy.verifyIsShown("getGoing")
        title = self.godaddy.getValueOf("title")
        self.godaddy.log("Title : " + title)

        self.godaddy.switchToWebView("NATIVE_APP")
        self.godaddy.swipeOfType("up")
        self.godaddy.waitForTimeOut(1000)
        self.godaddy.switchToWebView("WEBVIEW_1")

        self.godaddy.verifyIsShown("domainSearch")
        self.godaddy.clickOn("domainSearch")
        self.godaddy.waitForTimeOut(2000)
        # set value and search results
        self.godaddy.setValueTo("domainSearch","test")
        self.godaddy.waitForTimeOut(1000)
        self.godaddy.verifyIsShown("domainSearchButton")
        self.godaddy.clickOn("domainSearchButton")

        self.godaddy.waitForTimeOut(2000)
        self.godaddy.verifyIsShown("firstResult")
        self.godaddy.verifyIsShown("logo")

        reuslt = self.godaddy.getValueOf("firstResult")
        self.godaddy.log("Get First Result : " + reuslt)

        self.godaddy.switchToWebView("NATIVE_APP")
        self.godaddy.swipeOfType("up")
        self.godaddy.waitForTimeOut(1000)
        self.godaddy.swipeOfType("up")
        self.godaddy.waitForTimeOut(1000)
        self.godaddy.getScreenShot("SearchReulst.png")
        self.godaddy.quit()