__author__ = 'Justin'

import os

from src.base.core.UiFramework import UIFramework
from selenium.common.exceptions import NoSuchElementException
from appium import webdriver

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)


class Android(UIFramework):

    def __init__(self):
        UIFramework.__init__(self)

    def getAppType(self):
        return "Android"


    def __launch_app(self):
        #os.system(r'taskkill /f /im node.exe')
        #os.system(r'start E:\Autotest\Tools\Appium_1_4_6\Appium\node.exe E:\Autotest\Tools\Appium_1_4_6\Appium\node_modules\appium\lib\server\main.js --address 127.0.0.1 --port 4723 --no-reset --platform-name Android')
        '''desired_caps = {}
desired_caps['platformName']= self._getSutFullFileName("app.device.platformName")
desired_caps['deviceName'] = self._getSutFullFileName("app.device.name")
desired_caps['version'] = self._getSutFullFileName("app.device.version")
desired_caps['newCommandTimeout'] = self._getSutFullFileName("app.command.timeout")
desired_caps['app'] = PATH(self._getSutFullFileName("app.path"))
desired_caps['app-package'] = self._getSutFullFileName("app.package")
desired_caps['app-activity'] = self._getSutFullFileName("app.activity")
desired_caps['appWaitActivity'] = self._getSutFullFileName("app.activity")
self._driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub',desired_caps)
self._waitByTimeOut(5000)'''

        desired_caps = {}
        desired_caps['platformName'] = os.getenv("APPIUM_PLATFORM")
        desired_caps['platformVersion'] = os.getenv("APPIUM_DEVICE_VERSION")
        desired_caps['automationName'] = os.getenv("APPIUM_AUTOMATION_NAME")
        desired_caps['deviceName'] = os.getenv("APPIUM_DEVICE_NAME");
        desired_caps['newCommandTimeout'] = os.getenv("APPIUM_NEW_COMMAND_TIMEOUT")
        desired_caps['app'] = PATH(os.getenv("APPIUM_APP_FILE"))
        desired_caps['app-package'] = os.getenv("APPIUM_APP_PACKAGE")
        desired_caps['app-activity'] = os.getenv("APPIUM_APP_ACTIVITY")
        self._driver = webdriver.Remote(os.getenv("APPIUM_URL"), desired_caps)
        self._waitByTimeOut(5000)


    def __launch_browser(self):
        #os.system(r'taskkill /f /im node.exe')
        #os.system(r'start E:\Autotest\Tools\Appium_1_4_6\Appium\node.exe E:\Autotest\Tools\Appium_1_4_6\Appium\node_modules\appium\lib\server\main.js --address 127.0.0.1 --port 4723 --no-reset --platform-name Android')
        """desired_caps = {}
        desired_caps['platformName']= self._getSutFullFileName("app.device.platformName")
        desired_caps['browserName'] = ''
        desired_caps['deviceName'] = self._getSutFullFileName("app.device.name")
        desired_caps['version'] = self._getSutFullFileName("app.device.version")
        desired_caps['newCommandTimeout'] = self._getSutFullFileName("app.command.timeout")
        desired_caps['app'] = PATH(self._getSutFullFileName("app.path"))
        desired_caps['app-package'] = self._getSutFullFileName("app.package")
        desired_caps['app-activity'] = self._getSutFullFileName("app.activity")
        self._driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub',desired_caps)
        self._waitByTimeOut(5000)"""
        desired_caps = {}
        desired_caps['platformName'] = self._getSutFullFileName("app.device.platformName")
        desired_caps['version'] = self._getSutFullFileName("app.device.version")
        desired_caps['deviceName'] = self._getSutFullFileName("app.device.name")
        desired_caps['newCommandTimeout'] = self._getSutFullFileName("app.command.timeout")
        desired_caps['browserName'] = "chrome"
        self._driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)
        self._waitByTimeOut(5000)

        '''desired_caps['platformName'] = os.getenv("APPIUM_PLATFORM")
        desired_caps['platformVersion'] = os.getenv("APPIUM_DEVICE_VERSION")
        desired_caps['automationName'] = os.getenv("APPIUM_AUTOMATION_NAME")
        desired_caps['deviceName'] = os.getenv("APPIUM_DEVICE_NAME");
        desired_caps['newCommandTimeout'] = os.getenv("APPIUM_NEW_COMMAND_TIMEOUT")
        desired_caps['browserName'] = os.getenv("Chrome")
        self._driver = webdriver.Remote(os.getenv("APPIUM_URL"), desired_caps)
        self._waitByTimeOut(5000)'''

    def openApp(self, page = ""):
        self.UiMapSetPage(page)
        self.__launch_app()

    def openMobileBrowser(self, page = ""):
        self.UiMapSetPage(page)
        self.__launch_browser()
        self._waitByTimeOut(1000)
        self._driver.get(self._getSutFullFileName("test.url"))

    def getX(self):
        width = self._driver.get_window_size()['width']
        return width

    def getY(self):
        height = self._driver.get_window_size()['height']
        return height

    def swipeOfType(self,type):
        self.waitForTimeOut(500)
        self.log("Swiping " + type + ".")
        windows_x = self.getX()
        windows_y = self.getY()

        swipeLeft = "left"
        swipeLeftSide = "leftSide"
        swipeRight = "right"
        swipeRightSide = "rightSide"
        swipeUp = "up"
        swipeTop = "top"
        swipeDown = "down"
        swipeBottom = "bottom"

        # Sliding screen to the left
        if type.lower() == swipeLeft.lower():
            self._driver.swipe((windows_x * 0.9), (windows_y * 0.5),(windows_x * 0.2), (windows_y * 0.5),1500)
        # From the left of screen to began to slip
        if type.lower() == swipeLeftSide.lower():
            self._driver.swipe(1, (windows_y * 0.5),(windows_x * 0.9), (windows_y * 0.5),1500)
        # Sliding screen to the right
        if type.lower() == swipeRight.lower():
            self._driver.swipe((windows_x * 0.2), (windows_y * 0.5),(windows_x * 0.9), (windows_y * 0.5),1500)
        # From the right of screen to began to slip
        if type.lower() == swipeRightSide.lower():
            self._driver.swipe((windows_x * 0.9), (windows_y * 0.5),(windows_x * 0.2), (windows_y * 0.5),1500)
        # Screen upward sliding
        if type.lower() == swipeUp.lower():
            self._driver.swipe((windows_x * 0.5), (windows_y * 0.9),(windows_x * 0.5), (windows_y * 0.4),1500)
        # From the top of screen to began to slip
        if type.lower() == swipeTop.lower():
            self._driver.swipe((windows_x * 0.5),0 ,(windows_x * 0.5), (windows_y * 0.8),1500)
        # Slide down the screen
        if type.lower() == swipeDown.lower():
            self._driver.swipe((windows_x * 0.5), (windows_y * 0.4),(windows_x * 0.5), (windows_y * 0.9),1500)
        # From the bottom of screen to began to slip
        if type.lower() == swipeBottom.lower():
            self._driver.swipe((windows_x * 0.5), (windows_y * 0.9),(windows_x * 0.5), (windows_y * 0.1),1500)

    def swipeTo(self, begin_x,begin_y,end_x,end_y,duration=500):
        self._driver.swipe(begin_x,begin_y,end_x,end_y,duration)

    # x and y (1-10)
    def swipe(self,start_x,start_y,end_x,end_y):
        self.log("Swipe from [" + start_x + ":" + start_y + "] to [" + end_x + ":" + end_y + "].")
        windowlenX = self.getX()
        windowlenY = self.getY()
        self.swipeTo((windowlenX * start_x / 10), (windowlenY * start_y / 10),(windowlenX * end_x / 10),(windowlenY * end_y / 10), 1500)

    def tap(self,x, y,duration=500):
        width = self.getX()
        height = self.getY()
        self._driver.tap([(width * x,height * y)], duration)

    def back(self):
        self._driver.back()

    def pressKey(self,code):
        self._driver.long_press_keycode(code)

    def quit(self):
        self._driver.quit()

    def switchToWebView(self,viewName):
        self._driver.switch_to.context(viewName)

    def setValueByKeys(self,value):
        letterToCodeHashMap = {}
        lettersStr = "a b c d e f g h i j k l m n o p q r s t u v w x y z A B C D E F G H I J K L M N O P Q R S T U V W X Y Z @ . + _ 0 1 2 3 4 5 6 7 8 9".split()
        androidCodes = [29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52,
                        53, 54, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
                        51, 52, 53, 54, 77, 56, 81, 69, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
        for index in range(len(lettersStr)):
            letterToCodeHashMap[lettersStr[index]] = androidCodes[index]
        for i in range(len(value)):
            code = letterToCodeHashMap.get(value[i])
            self.pressKey(code)
            self.waitForTimeOut(500)

    def switchToContext(self, webView):
        contextName = self._driver.contexts
        for context in iter(contextName):
            if context == webView:
                self.log("Switch to web view : " + context)
                self.switchToWebView(context)

    def logContext(self):
        contextName = self._driver.contexts
        for context in iter(contextName):
            self.log("Context : " + context)

    def getScreenShot(self,name):
        self._driver.get_screenshot_as_file(os.getenv("APPIUM_SCREENSHOT_DIR")+name)
        #self._driver.get_screenshot_as_file("C:/Users/kevin/Desktop/Demo/"+name)