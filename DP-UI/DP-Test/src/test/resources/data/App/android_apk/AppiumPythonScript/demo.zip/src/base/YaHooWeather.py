# -*- coding: utf-8 -*-
__author__ = 'Justin'

import os
import time
from .fwk.AndroidFWK import Android

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

class yahooWeather(Android):

    def __init__(self):
        Android.__init__(self)

    def getAppName(self):
        return "yahooWeather"
