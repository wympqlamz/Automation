#coding=utf-8
__author__ = 'Justin'

from src.base.Ep2pApp import ep2p
import unittest

class Demo(unittest.TestCase):
    ep2p =None

    @classmethod
    def setUpClass(self):
        self.ep2p = ep2p()
        self.ep2p.openApp()
        # go to welcome page

    def test_ep2p_test1(self):
        for index in range(0,15):
            self.ep2p.getScreenShot("test"+str(index)+".png")
    @classmethod
    def tearDownClass(self):
        self.ep2p.quit()




"""
suite = unittest.TestSuite()
    suite.addTest(Demo('eprint_test1'))
    # suite =  unittest.TestLoader().loadTestsFromTestCase(MyTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
"""