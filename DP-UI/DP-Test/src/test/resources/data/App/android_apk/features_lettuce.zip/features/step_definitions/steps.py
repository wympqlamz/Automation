import os

from lettuce import *
from appium import webdriver
PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

@step('Launch App in my device')
def launch_app(step):
    desired_caps = {}
    desired_caps['platformName'] = os.getenv('APPIUM_PLATFORM') # default if 'Android'
    desired_caps['deviceName'] = os.getenv('APPIUM_DEVICE_NAME')
    desired_caps['app'] = os.getenv('APPIUM_APP_FILE')
    desired_caps['newCommandTimeout']= os.getenv('APPIUM_NEW_COMMAND_TIMEOUT')
    desired_caps['udid'] = os.getenv('APPIUM_DEVICE_UDID')

    world.driver = webdriver.Remote(os.getenv('APPIUM_URL'), desired_caps)

@step('I see the (.*) button')
def check_button(step, expected):
    print os.getenv('APPIUM_SCREENSHOT_DIR')
    world.driver.find_element_by_android_uiautomator('new UiSelector().text("'+expected+'")')


@step('Click object, input')
def input_data(step):
        textfields = world.driver.find_elements_by_class_name("android.widget.EditText")
        textfields[0].send_keys("Appium User")
        textfields[1].send_keys("someone@appium.io")

@step('click (.*) object')
def click_object(step,element):
    melment=world.driver.find_element_by_android_uiautomator('new UiSelector().text("'+element+'")')
    melment.click()

@step('I take a screenshot: (.*)')
def getScreenShot(self, fileName):
        world.driver.get_screenshot_as_file(os.getenv("APPIUM_SCREENSHOT_DIR") + fileName  +".png")
        #world.driver.get_screenshot_as_file("/Users/bys_automation_user/Downloads/device-pass/lettuce/githublogin_python_upload/screen" + fileName  +".png")